﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliBlackJack
{
    public class Hand : IBlackJack
    {
        private Deck playDeck;
        private Deck playerDeck;
        private Deck dealerDeck;
        private string playerName;
        private  int playerScore = 0;
        private  int dealerScore = 0;
        private const int BLACKJACK = 21;

        protected Deck PlayDeck { get => playDeck; set => playDeck = value; }
        protected Deck PlayerDeck { get => playerDeck; set => playerDeck = value; }
        protected Deck DealerDeck { get => dealerDeck; set => dealerDeck = value; }
        public string PlayerName { get => playerName; set => playerName = value; }
        public int PlayerScore { get => playerScore; set => playerScore = value; }
        public int DealerScore { get => dealerScore; set => dealerScore = value; }

        public Hand() 
        {
            PlayerDeck = new Deck();
            DealerDeck = new Deck();
            PlayDeck = new Deck();
            PlayDeck.createDeck();
            
        }

        public string GetPlayerName(string name)
        {
            return PlayerName = name;
        }

        public void Jouer()
        {
            DealCard();         
        }

        

        public void VoirScore()
        {
            Console.WriteLine($"Dealer's Score: {DealerScore}");
            Console.WriteLine($"Player's Score: {PlayerScore}");

            string winner = " ";
            if (DealerScore > PlayerScore)
            {
                winner = "The winner is Dealer";
            }
            else if (DealerScore < PlayerScore)
            {
                winner = $"The winner is {PlayerName}";
            }
            else 
            {
                winner = "No winner";
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\t {winner}");
            Console.ResetColor();
        }

        public void DealCard()
        {
            int i = 1;
            while ((PlayerScore < 4) && (DealerScore < 4)) 
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("******************************************************");
                Console.WriteLine($"\t {i ++} Round");
                Console.WriteLine($"\t {PlayerName} vs Dealer");
                Console.WriteLine("******************************************************");
                Console.ResetColor();

                PlayDeck.shuffle();
                bool endRound = false;

                PlayerDeck.draw(PlayDeck);
                PlayerDeck.draw(PlayDeck);
                DealerDeck.draw(PlayDeck);
                DealerDeck.draw(PlayDeck);

                while (true)
                {
                    Console.WriteLine("\n");

                    Console.Write($"\t{PlayerName}'s hand: "); ;
                    Console.Write($"\t{PlayerDeck.ToString()}, ");
                    Console.WriteLine();
                    Console.Write($"\t{PlayerName}'s hand value : ");
                    Console.WriteLine($"\t{PlayerDeck.cardsValue()} ");

                    Console.WriteLine($"\n\tDealer hand: {DealerDeck.GetCard(0).ToString()} and [Hidden]\n");
                    //Console.WriteLine($"\n\tDealer hand: {DealerDeck.ToString()} and [Hidden]\n");

                    if (PlayerDeck.cardsValue().Equals(BLACKJACK) &&
                        endRound.Equals(false) &&
                        PlayerDeck.deckSize().Equals(2) /*&&*/
                        /*(!PlayerDeck.Cards.Contains((Card)Enum.Parse(typeof(Value), "TEN")))*/)
                    {
                        Console.WriteLine($"\t{PlayerName}'s value: {PlayerDeck.cardsValue()}");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"\t {PlayerName} BLACKJACK! BLACKJACK! BLACKJACK!");
                        Console.ResetColor();
                        playerScore += 2;
                        endRound = true;
                        break;
                    }

                    string response =" ";
                    
                    Console.WriteLine($"\t{PlayerName}, Would you like to (1)Hit or (2)Stand?");
                    
                    response = Console.ReadLine();
                    if (string.IsNullOrWhiteSpace(response))
                    {
                        Console.WriteLine("Enter your choice: [(1)Hit or (2)Stand]");
                        response = Console.ReadLine();
                    }
                    Console.WriteLine("\n");
                    if (response.Equals("1"))
                    {
                        PlayerDeck.draw(PlayDeck);
                        Console.WriteLine($"\t{PlayerName} draws a: {PlayerDeck.GetCard(PlayerDeck.deckSize() - 1).ToString()}");

                        if (PlayerDeck.cardsValue().Equals(BLACKJACK) && endRound.Equals(false))
                        {
                            Console.WriteLine($"\t{PlayerName} got {PlayerDeck.cardsValue()}");
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine($"\t BLACKJACK! BLACKJACK! BLACKJACK!");
                            Console.ResetColor();
                            PlayerScore += 1;
                            endRound = true;
                            break;

                        }

                        if (PlayerDeck.cardsValue() > BLACKJACK && endRound.Equals(false))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"Bust. currently valued at: {PlayerDeck.cardsValue()}");
                            Console.ResetColor();
                            DealerScore += 1;
                            endRound = true;
                            break;
                        }
                    }

                    if (response.Equals("2"))
                    {
                        break;
                    }
                }

                Console.WriteLine($"Dealer Cards: {DealerDeck.cardsValue().ToString()}\n");
                Console.ReadKey();
                if (DealerDeck.cardsValue().Equals(BLACKJACK) &&
                    endRound.Equals(false) &&
                    DealerDeck.deckSize().Equals(2))
                {
                    Console.WriteLine($"\tDealer got {DealerDeck.cardsValue()}");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\tDealer, BLACKJACK! BLACKJACK! BLACKJACK!");
                    Console.ResetColor();
                    DealerScore += 2;
                    endRound = true;
                }

                if (DealerDeck.cardsValue() > playerDeck.cardsValue() && endRound.Equals(false))
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"\tDealer beats player!");
                    Console.ResetColor();
                    DealerScore += 1;
                    endRound = true;
                }

                while (DealerDeck.cardsValue() < 17 && endRound.Equals(false))
                {
                    DealerDeck.draw(playDeck);
                    Console.WriteLine($"Dealer draws : {DealerDeck.GetCard(DealerDeck.deckSize() - 1).ToString()}");
                    
                    if (DealerDeck.cardsValue().Equals(BLACKJACK) && endRound.Equals(false))
                    {
                        Console.WriteLine($"\tDealer got {DealerDeck.cardsValue()}");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"\t BLACKJACK! BLACKJACK! BLACKJACK!");
                        Console.ResetColor();
                        DealerScore += 1;
                        endRound = true;
                    }
                }

                Console.WriteLine($"Dealer's hand value: {DealerDeck.cardsValue()}");
                if (DealerDeck.cardsValue() > BLACKJACK && endRound.Equals(false))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Dealer busts! Player won");
                    Console.ResetColor();
                    PlayerScore += 1;
                    endRound = true;
                }

                if (PlayerDeck.cardsValue().Equals(DealerDeck.cardsValue()) && endRound.Equals(false))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Push");
                    Console.ResetColor();
                    endRound = true;
                }

                if (PlayerDeck.cardsValue() > DealerDeck.cardsValue() && endRound.Equals(false))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Player won the hand!");
                    Console.ResetColor();
                    playerScore += 1;
                    endRound = true;
                }

                if (DealerDeck.cardsValue() > PlayerDeck.cardsValue() && endRound.Equals(false))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Dealer won the hand!");
                    Console.ResetColor();
                    dealerScore += 1;
                    endRound = true;
                }

                PlayerDeck.moveAllToDeck(PlayDeck);
                dealerDeck.moveAllToDeck(PlayDeck);

                Console.WriteLine($"End of hand.");
                Console.WriteLine("\n\n=============================================================\n");

                VoirScore();
                Console.ReadKey();

            }
            
            string finalWinner =
                DealerScore > PlayerScore ? " Dealer" : $" {PlayerName}";
            Console.Write("\tThe Final Winner is");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine($"\t{finalWinner}");
            Console.ResetColor();
            Console.ReadKey();
            
        }

    }
}
