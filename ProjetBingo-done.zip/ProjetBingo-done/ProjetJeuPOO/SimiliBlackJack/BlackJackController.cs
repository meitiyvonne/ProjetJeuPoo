﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliBlackJack
{
    public class BlackJackController
    {   
        public void StartBlackJack(string name)
        {
            Console.WriteLine($"Bonjour {name}");

            Hand hand = new Hand();
            hand.GetPlayerName(name);
            hand.Jouer();

            ProgramStartMenu programStartMenu = new ProgramStartMenu();
            programStartMenu.StartMenu();
            Console.ReadKey();
        }

        
    }
}
