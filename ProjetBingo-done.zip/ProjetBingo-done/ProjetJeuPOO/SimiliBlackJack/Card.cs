﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ProjetJeuPOO.SimiliBlackJack
{
    public class Card
    {
        private Suits suits;
        private Value value;

        public Card(Suits suit, Value value) 
        {
            this.Suits = suit;
            this.Value = value;
        }

        public Suits Suits { get => suits; set => suits = value; }
        public Value Value { get => value; set => this.value = value; }

        public override string ToString()
        {
            return this.Suits.ToString()+"-"+this.Value.ToString();
        }


    }

    
}
