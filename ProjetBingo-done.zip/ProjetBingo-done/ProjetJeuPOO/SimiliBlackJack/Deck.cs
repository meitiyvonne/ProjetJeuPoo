﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjetJeuPOO.SimiliBlackJack
{
    public class Deck
    {
        private List<Card> cards;

        public List<Card> Cards { get => cards; set => cards = value; }


        public Deck()
        {
            this.cards = new List<Card>();
        }

        // putting cards into deck
        public void createDeck()
        {
            foreach(Suits CardSuits in Enum.GetValues(typeof(Suits)))
            {
                foreach (Value CardValue in Enum.GetValues(typeof(Value))) 
                {
                    cards.Add(new Card(CardSuits, CardValue));
                }
            
            }
        }

        public void shuffle()
        {
            List<Card> tmp = new List<Card>();
            Random random = new Random();

            int rnCardIndex = 0;
            int originalSize = cards.Count;
            for (int i = 0; i < originalSize; i++) 
            {
                rnCardIndex = random.Next(cards.Count - 1);
                tmp.Add(cards[rnCardIndex]);
                cards.RemoveAt(rnCardIndex);

            }
            cards = tmp;
        }

        public void removeCard(int index)
        {
            cards.RemoveAt(index);
        }

        public Card GetCard(int i)
        {
            return cards[i];
        }

        public void AddCard(Card addCard)
        {
            cards.Add(addCard);
        }

        public void draw(Deck from)
        {
            cards.Add(from.GetCard(0));
            from.removeCard(0);
        }

        public int deckSize()
        {
            return cards.Count;
        }

        public void moveAllToDeck(Deck moveTo)
        {
            int thisDeckSize = cards.Count;

            for(int i=0; i<thisDeckSize; i++)
            {
                moveTo.AddCard(this.GetCard(i));
            }

            for(int i=0; i<thisDeckSize; i++)
            {
                this.removeCard(0);
            }
        }

        public int cardsValue()
        {
            int totalVal = 0;
            int aces = 0;

            foreach(Card aCard in cards)
            {
                switch (aCard.Value) 
                {
                    case Value.TWO:
                        totalVal += 2; 
                        break;
                    case Value.THREE:
                        totalVal += 3;
                        break;
                    case Value.FOUR:
                        totalVal += 4;
                        break;
                    case Value.FIVE:
                        totalVal += 5;
                        break;
                    case Value.SIX:
                        totalVal += 6;
                        break;
                    case Value.SEVEN:
                        totalVal += 7;
                        break;
                    case Value.EIGHT:
                        totalVal += 8;
                        break;
                    case Value.NINE:
                        totalVal += 9;
                        break;
                    case Value.TEN:
                        totalVal += 10;
                        break;
                    case Value.JACK:
                        totalVal += 10;
                        break;
                    case Value.QUEEN:
                        totalVal += 10;
                        break;
                    case Value.KING:
                        totalVal += 10;
                        break;
                    case Value.ACE:
                        aces += 1;
                        break;
                }
            }
            //Card a = (Card)Enum.Parse(typeof(Value), "ACE");
            
            for (int i = 0; i < aces; i++)
            {

                if (totalVal > 10)
                {
                    totalVal += 1;
                }
                else
                {
                    totalVal += 11;
                }
            }
            return totalVal;
        }

        public override string ToString()
        {
            string cardList = " ";
            
            foreach (Card aCard in cards) 
            {
                cardList += "\n " + aCard.ToString();
               
            }
            return cardList;
        }
    }
}
