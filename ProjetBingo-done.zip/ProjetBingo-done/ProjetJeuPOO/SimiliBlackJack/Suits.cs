﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliBlackJack
{
    public enum Suits
    {
        SPADE, DIAMOND, HEART, CLUB
    }
}
