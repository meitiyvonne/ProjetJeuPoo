﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliBlackJack
{
    interface IBlackJack
    {
        public void Jouer();
        public void VoirScore();
        public void DealCard();
    }
}
