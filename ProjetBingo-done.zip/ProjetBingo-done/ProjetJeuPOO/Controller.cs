﻿using System;
using ProjetJeuPOO.Bingo;
using ProjetJeuPOO.SimiliBlackJack;
using ProjetJeuPOO.SimiliPendu;

namespace ProjetJeuPOO
{
    class Controller
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Projet POO");
            ProgramStartMenu programStartMenu = new ProgramStartMenu();
            programStartMenu.StartMenu();

            Console.ReadKey();

        }
    }
}
