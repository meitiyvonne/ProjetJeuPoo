﻿using ProjetJeuPOO.Bingo;
using ProjetJeuPOO.SimiliBlackJack;
using ProjetJeuPOO.SimiliPendu;
using System;

namespace ProjetJeuPOO
{
    public class ProgramStartMenu
    {
        public static string name;
        public void StartMenu()
        {
            Console.Clear();
            Console.WriteLine("\t1- Bingo");
            Console.WriteLine("\t2- Simili black jack");
            Console.WriteLine("\t3- Le pendu");
            Console.WriteLine("\t4- Quitter");

            Console.WriteLine("\tSelect your game: ");
            string choix = Console.ReadLine();

            switch (choix)
            {
                case "1":
                    Console.Clear();
                    if (String.IsNullOrEmpty(name))
                    {
                        Console.WriteLine("\tEnter your name: ");
                        name = Console.ReadLine();
                    }
                    BingoCardMenu bingoMenuCard = new BingoCardMenu();
                    bingoMenuCard.BingoMenu(name);
                    break;
                case "2":
                    BlackJackController blackJack = new BlackJackController();
                    Console.WriteLine($"Welcome to Black Jack");
                    if (String.IsNullOrEmpty(name))
                    {
                        Console.WriteLine("\tEnter your name: ");
                        name = Console.ReadLine();
                    }
                    blackJack.StartBlackJack(name);

                    break;
                case "3":
                    Pendu pendu = new Pendu();
                    Console.WriteLine("Le jeu du pendu");
                    if (String.IsNullOrEmpty(name))
                    {
                        Console.WriteLine("\tEnter your name: ");
                        name = Console.ReadLine();
                    }
                    pendu.StartPendu(name);
                    break;
                case "4":
                    Console.WriteLine("Au revoir");
                    break;
            }
        }

        
    }
}