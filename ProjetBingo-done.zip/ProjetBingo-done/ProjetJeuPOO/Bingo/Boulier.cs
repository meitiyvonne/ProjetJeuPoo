﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Classe qui représente le boulier. On y retire les boules au hazard.

namespace ProjetJeuPOO.Bingo
{

    public class Boulier : IBingoBoulier
    {
        private List<int> rns = new List<int>();
        protected static List<BingoBall> bingoBalls = new List<BingoBall>();
        public void add(BingoBall element)
        {
        }
                
        public int getRandomBall()
        {   
            Dictionary<char, BingoBall> dict = bingoBalls.ToDictionary(p => p.Letter);
            Random random = new Random();
            int rn;

            do rn = random.Next(1, 76);
            while (rns.Contains(rn));

            rns.Add(rn);
            
            return rn;
        }

        public int getSize()
        {
            return 0;
        }

        public bool isEmpty()
        {
            bool b = false;
            return b;
        }

        public void restartBoulier(List<BingoBall> bingoBalls)
        {
            foreach (var k in bingoBalls)
            {
                k.Numbers.ToArray();
                for (int i = 0; i < k.Numbers.Count; i++)
                {
                    k.Numbers[i] = 0;
                }
                Console.WriteLine();
            }
        }
    }

}

