﻿using System;
using System.Collections.Generic;
using System.Text;

//Classe représentant un objet boule 

namespace ProjetJeuPOO.Bingo
{
    public class BingoBall
    {
        private char letter;
        private int number;
        private List<int> numbers;
        public BingoBall() { }
        public BingoBall(char letter, List<int> numbers)
        {
            Letter = letter;
            Numbers = numbers;

        }
        public char Letter { get => letter; set => letter = value; }
        public int Number { get => number; set => number = value; }
        public List<int> Numbers { get => numbers; set => numbers = value; }
    }
}
