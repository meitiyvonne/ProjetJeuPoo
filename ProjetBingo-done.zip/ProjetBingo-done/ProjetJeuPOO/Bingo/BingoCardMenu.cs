﻿using System;
using System.Linq;

namespace ProjetJeuPOO.Bingo
{
    public class BingoCardMenu
    {
        private BingoCard bingoCard;
        private ProgramStartMenu programStartMenu;

        private int numOfCard=0;

        public BingoCard BingoCard { get => bingoCard; set => bingoCard = value; }
        public ProgramStartMenu ProgramStartMenu { get => programStartMenu; set => programStartMenu = value; }
        public int NumOfCard { get => numOfCard; set => numOfCard = value; }

        private BingoCard GetBingoCard()
        {
            BingoCard bingoCard = BingoCard.GetInstance();
            return bingoCard;
        }

        public ProgramStartMenu GetProgramStartMenu()
        {
            ProgramStartMenu programStartMenu = new ProgramStartMenu();
            return programStartMenu;
        }


        public void BingoMenu(string name)
        {

            Console.Clear();
            Console.WriteLine($"\tHi, {name}");
            Console.WriteLine();

            Console.WriteLine("\tChoisir l'option suivante :");
            Console.WriteLine("\t1-Initialiser une nouvelle partie");
            Console.WriteLine("\t2-Visualiser une carte");
            Console.WriteLine("\t3-Visualiser la carte de l'annonceur");
            Console.WriteLine("\t4-Tirez une boule");
            Console.WriteLine("\t5-Fin de partie");
            string choix = Console.ReadLine();
            bool b = VerifyInput(choix);
            if (!b)
            {
                Console.WriteLine("Enter can't be empty or invalid number.");
                Console.ReadKey();
                BingoMenu(name);
            }
            else { 
                switch (choix)
                {
                    case "1":
                        Console.WriteLine("\tCombien de cartes désirez-vous : (max de 4)");
                        string na = Console.ReadLine();
                        if (string.IsNullOrEmpty(na))
                        {
                            Console.WriteLine("Can not be Empty");
                            Console.ReadKey();
                        }
                        else
                        {
                            NumOfCard = int.Parse(na);
                            if (GetBingoCard().VerifyInput(NumOfCard))
                            {
                                NumOfCard = 0;
                                Console.WriteLine("Oops, max de 4 cartes!!!");
                                 
                            }
                            GetBingoCard().PlayerName = name;
                            GetBingoCard().NumberOfCards(NumOfCard);
                        }

                        BingoMenu(name);
                        break;
                    case "2":
                        GetBingoCard().ShowPlayerCards();
                        BingoMenu(name);
                        break;
                    case "3":
                        GetBingoCard().ShowInitialCard();
                        BingoMenu(name);                    
                        break;
                    case "4":
                        GetBingoCard().PickBall();                        
                        BingoMenu(name);                        
                        
                        break;
                    case "5":
                        GetProgramStartMenu().StartMenu();
                        break;

                }
            }
            
        }

        private bool VerifyInput(string choix)
        {
            bool b = true;
            if (string.IsNullOrEmpty(choix))
            {
                b = false;
            }
            return b;
        }
    }
}