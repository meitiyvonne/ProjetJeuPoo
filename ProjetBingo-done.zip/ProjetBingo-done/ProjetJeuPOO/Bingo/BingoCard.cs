﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Classe représentant un objet carte pour le joueur.
// Un joueur a au minimum une carte.

namespace ProjetJeuPOO.Bingo
{
    public class BingoCard
    {
        protected static List<BingoBall> bingoBalls = new List<BingoBall>();
        protected static BingoCard instance;
        private string playerName;
        protected static int winTimes = 0;
        protected static int numberCards;
        protected static bool isBingo = false;

        protected Dictionary<char, BingoBall>[] player = new Dictionary<char, BingoBall>[4];

        private Boulier boulier = new Boulier();
        private List<int> rns = new List<int>();

        private List<int> savedCards = new List<int>();
        private int[,] arrls = new int[5, 5];
        private List<List<int>> newSavedCards = new List<List<int>>();

        protected int NumberCards { get => numberCards; set => numberCards = value; }
        public string PlayerName { get => playerName; set => playerName = value; }
        protected Boulier Boulier { get => boulier; set => boulier = value; }

        private BingoCard()
        {
            List<int> b = Enumerable.Range(1, 15).ToList();
            List<int> i = Enumerable.Range(16, 15).ToList();
            List<int> n = Enumerable.Range(31, 15).ToList();
            List<int> g = Enumerable.Range(46, 15).ToList();
            List<int> o = Enumerable.Range(61, 15).ToList();
            bingoBalls.Add(new BingoBall('B', b));
            bingoBalls.Add(new BingoBall('I', i));
            bingoBalls.Add(new BingoBall('N', n));
            bingoBalls.Add(new BingoBall('G', g));
            bingoBalls.Add(new BingoBall('O', o));


            InitializeBingoCard();
            rns.Clear();
            savedCards.Clear();
            NumberCards = 0;


        }

        public void InitializeBingoCard()
        {
            Boulier.restartBoulier(bingoBalls);
            
        }

        public void ShowInitialCard()
        {
            // initalize BingoCard board to value 0
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\t======================================================= Bingo Boulier =======================================================");
            Console.ResetColor();
            foreach (var k in bingoBalls)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write($" \t{k.Letter}");
                Console.ResetColor();
                k.Numbers.ToArray();
                for (int i = 0; i < k.Numbers.Count; i++)
                {
                    k.Numbers[i] = 0;
                    Console.Write($"\t{k.Numbers[i]}");
                }
                Console.WriteLine();
            }
            rns.Clear();
            savedCards.Clear();

            Console.ReadKey();
        }

        public void PickBall()
        {
            if (HasPlayerCards())
            {
                Console.WriteLine("You need to have some bingo cards first.");
                Console.ReadKey();
            }
            else
            {
                AddBall();
                ShowUpdateBingoCard();
                if (isBingo)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\t=======================================================");
                    Console.WriteLine($"\tWinner {PlayerName}, Times: {winTimes} ");
                    Console.WriteLine($"\t{PlayerName}, would you like to play again? ( y | n )");

                    Console.WriteLine("\t=======================================================");
                    string response = Console.ReadLine();
                    Console.ReadKey();
                    if (response.ToLower().Equals("y") || response.ToLower().Equals("n"))
                    {

                        Reset();
                    }
                }
                Console.ResetColor();
            }
        }
        public bool HasPlayerCards()
        {
            return (player[0] is null);
        }


        public ref List<BingoBall> AddBall()
        {
            Dictionary<char, BingoBall> dict = bingoBalls.ToDictionary(p => p.Letter);
            
            int rn = Boulier.getRandomBall();

            rns.Add(rn);
            Console.WriteLine($"Picked Balls :");
            foreach (var v in rns)
            {
                Console.Write($" {v} ");
            }
            Console.WriteLine();
            Console.Write($"picking random ball: ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($" {rn} ");

            Console.ResetColor();

            Console.WriteLine("\t=======================================================");

            if (Enumerable.Range(0, 15).Contains(rn))
            {
                int i = rn - 1;
                if (dict['B'].Numbers[i].Equals(0))
                {
                    dict['B'].Numbers[i] = rn;
                }

            }
            else if (Enumerable.Range(16, 15).Contains(rn))
            {
                int i = (rn - 1) - 15;
                if (dict['I'].Numbers[i].Equals(0))
                {
                    dict['I'].Numbers[i] = rn;
                }
            }
            else if (Enumerable.Range(31, 15).Contains(rn))
            {
                int i = (rn - 1) - (15 * 2);
                if (dict['N'].Numbers[i].Equals(0))
                {
                    dict['N'].Numbers[i] = rn;

                }
            }
            else if (Enumerable.Range(46, 15).Contains(rn))
            {
                int i = (rn - 1) - (15 * 3);
                if (dict['G'].Numbers[i].Equals(0))
                {

                    dict['G'].Numbers[i] = rn;
                }
            }
            else if (Enumerable.Range(61, 15).Contains(rn))
            {
                int i = (rn - 1) - (15 * 4);
                if (dict['O'].Numbers[i].Equals(0))
                {

                    dict['O'].Numbers[i] = rn;
                }
            }

            Console.WriteLine();
            UpdatePlayerCard(rn);
            VerifyPlayerListCard(rn);

            Console.WriteLine();
            ShowPlayerListCard();

            return ref bingoBalls;
        }

        public ref List<List<int>> VerifyPlayerListCard(int rn)
        {
            newSavedCards.ToArray();
            for (int d = 0; d < newSavedCards.Count; d++)
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {

                        if (newSavedCards[d][i * 5 + j].Equals(rn))
                        {
                            newSavedCards[d][i * 5 + j] = 0;
                        }
                    }
                }
            }

            return ref newSavedCards;           

        }

        public void ShowPlayerListCard()
        {
            for (int d = 0; d < newSavedCards.Count; d++)
            {
                Console.WriteLine("\t=======================================================");
                Console.WriteLine($"\t\t player {PlayerName}, Card:{d + 1} ");
                Console.WriteLine("\t=======================================================");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\tB\tI\tN\tG\tO");
                Console.ResetColor();

                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (newSavedCards[d][j * 5 + i].Equals(0))
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                        }
                        Console.Write($"\t{newSavedCards[d][j * 5 + i]}");

                        Console.ResetColor();
                    }
                    Console.WriteLine();
                }

                Console.WriteLine("\t=======================================================");
            }
        }


        public ref Dictionary<char, BingoBall>[] UpdatePlayerCard(int rn)
        {
            for (int it = 0; it < player.Length; it++)
            {
                foreach (KeyValuePair<char, BingoBall> kvp in player[it])
                {
                    if (player[it].ContainsKey(kvp.Key))
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            if (kvp.Value.Numbers[i].Equals(rn))
                            {
                                player[it][kvp.Key].Numbers[i] = 0;
                            }
                        }
                    }
                }
            }

            VerifyPlayerListCard();

            return ref player;
        }

        public void VerifyPlayerListCard()
        {


            // verify bingo
            for (int it = 0; it < player.Length; it++)
            {
                foreach (KeyValuePair<char, BingoBall> kvp in player[it])
                {
                    // vertical
                    int zero = 0;
                    if (player[it].ContainsKey(kvp.Key))
                    {
                        for (int i = 0; i < 5; i++)
                        {
                            zero += kvp.Value.Numbers[i];
                        }
                        if (zero.Equals(0))
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            CallBingo(kvp.Key, it);
                            isBingo = true;
                            return;
                        }

                        Console.ResetColor();

                    }
                    // diagonal
                    else if ((player[it]['B'].Numbers[0] +
                                player[it]['I'].Numbers[1] +
                                player[it]['N'].Numbers[2] +
                                player[it]['G'].Numbers[3] +
                                player[it]['O'].Numbers[4]).Equals(0))
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        CallBingo(kvp.Key, it);
                        isBingo = true;
                        return;
                    }
                    // diagonal
                    else if ((player[it]['B'].Numbers[4] +
                               player[it]['I'].Numbers[3] +
                               player[it]['N'].Numbers[2] +
                               player[it]['G'].Numbers[1] +
                               player[it]['O'].Numbers[0]).Equals(0))
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        CallBingo(kvp.Key, it);
                        isBingo = true;
                        return;
                    }
                    Console.ResetColor();

                    // horizontal
                    int h = 0;
                    while (h >= 0 && h < 5)
                    {
                        zero = 0;
                        zero = (player[it]['B'].Numbers[h] +
                                player[it]['I'].Numbers[h] +
                                player[it]['N'].Numbers[h] +
                                player[it]['G'].Numbers[h] +
                                player[it]['O'].Numbers[h]);
                        if (zero.Equals(0))
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            CallBingo(kvp.Key, it);
                            isBingo = true;
                            return;
                        }
                        h++;
                        Console.ResetColor();

                    }
                }

            }

        }

        public void ShowUpdateBingoCard()
        {
            // initalize BingoCard board to value 0
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\t======================================================= Bingo Boulier =======================================================");
            Console.ResetColor();
            foreach (var k in bingoBalls)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write($" \t{k.Letter}");
                Console.ResetColor();
                k.Numbers.ToArray();
                for (int i = 0; i < k.Numbers.Count; i++)
                {
                    if (!(k.Numbers[i].Equals(0)))
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                    }

                    Console.Write($"\t{k.Numbers[i]}");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }

        public void CallBingo(char key, int it)

        {
            Console.Write($"\tBingo ! Bingo ! Bingo !");
            Console.WriteLine($"Player: {PlayerName},  Card-{it + 1} | { key}, {++winTimes} ");
            Console.ReadKey();
            Console.ResetColor();

        }

        public void Reset()
        {
            InitializeBingoCard();
            rns.Clear();
            savedCards.Clear();
            NumberCards = 0;
            player[0] = null;
            isBingo = false;

        }
        public static BingoCard GetInstance()
        {
            if (instance == null)
            {
                instance = new BingoCard();
            }
            return instance;
        }

        public ref List<BingoBall> UpdateBingoCard(int itself)
        {
            foreach (var k in bingoBalls)
            {
                Console.Write($" \t{k.Letter}");
                k.Numbers.ToArray();
                Console.WriteLine($"\tNumbers count: {k.Numbers.Count}"); // 15 for each Letter
                for (int i = 0; i < k.Numbers.Count; i++)
                {
                    if (i.Equals(itself))
                    {
                        k.Numbers[i] = itself;
                    }
                    Console.Write($"\t{k.Numbers[i]}");
                }
                Console.WriteLine();
            }
            Console.ReadKey();

            return ref bingoBalls;
        }
        // ================== Player Card ========================
        // VerifyInput card number > 4, error
        public bool VerifyInput(int numCards)
        {
            NumberCards = numCards;
            return (NumberCards > 4);
        }

        public void NumberOfCards(int n)
        {
            NumberCards = n;
            savedCards.Clear();
            player = new Dictionary<char, BingoBall>[NumberCards];

            Console.WriteLine($"Creating {NumberCards} new bingo card(s).");
            for (int i = 0; i < NumberCards; i++)
            {
                CreatePlayerCards(i + 1);

            }
            Console.WriteLine();
        }

        public void CreatePlayerCards(int nu)
        {
            int p = (nu - 1);
            List<int> ls = new List<int>();
            List<int> arr = new List<int>();
            List<BingoBall> playerBalls = new List<BingoBall>();
            Random rand = new Random();

            // create 5 int[] with size 5
            int[] bb = new int[5];
            int[] ib = new int[5];
            int[] nb = new int[5];
            int[] gb = new int[5];
            int[] ob = new int[5];
            playerBalls.Add(new BingoBall('B', bb.ToList()));
            playerBalls.Add(new BingoBall('I', ib.ToList()));
            playerBalls.Add(new BingoBall('N', nb.ToList()));
            playerBalls.Add(new BingoBall('G', gb.ToList()));
            playerBalls.Add(new BingoBall('O', ob.ToList()));

            player[p] = playerBalls.ToDictionary(p => p.Letter);


            int x = 0;
            for (int i = 0; i < 5; i++)
            {
                x = rand.Next(1, 16);
                if (!(ls.Contains(x)))
                {
                    bb[i] = x;
                    ls.Add(x);

                }
                else
                {
                    i--;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                x = rand.Next(16, 31);
                if (!(ls.Contains(x)))
                {
                    ib[i] = x;
                    ls.Add(x);
                }
                else
                {
                    i--;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                x = rand.Next(31, 46);
                if (!(ls.Contains(x)))
                {
                    nb[i] = x;
                    ls.Add(x);
                }
                else
                {
                    i--;
                }

            }

            for (int i = 0; i < 5; i++)
            {
                x = rand.Next(46, 61);
                if (!(ls.Contains(x)))
                {
                    gb[i] = x;
                    ls.Add(x);
                }
                else
                {
                    i--;
                }
            }

            for (int i = 0; i < 5; i++)
            {
                x = rand.Next(61, 76);
                if (!(ls.Contains(x)))
                {
                    ob[i] = x;
                    ls.Add(x);
                }
                else
                {
                    i--;
                }
            }
            //"==============End Random====================");

            Array.Sort(bb);
            Array.Sort(ib);
            Array.Sort(nb);
            Array.Sort(gb);
            Array.Sort(ob);
            // setup nb[2]=0                
            nb[2] = 0;


            arr.AddRange(bb);
            arr.AddRange(ib);
            arr.AddRange(nb);
            arr.AddRange(gb);
            arr.AddRange(ob);


            for (int i = 0; i < 5; i++)
            {
                player[p]['B'].Numbers[i] = bb[i];
                player[p]['I'].Numbers[i] = ib[i];
                player[p]['N'].Numbers[i] = nb[i];
                player[p]['G'].Numbers[i] = gb[i];
                player[p]['O'].Numbers[i] = ob[i];

            }

            savedCards.AddRange(arr);

            arr.ToArray();
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    arrls[i, j] = arr[i * 5 + j];
                }
            }     
        }


        public static List<List<int>> SplitList(List<int> source, int nSize)
        {
            var list = new List<List<int>>();

            for (int i = 0; i < source.Count; i += nSize)
            {
                list.Add(source.GetRange(i, Math.Min(nSize, source.Count - i)));
            }

            return list;
        }

        public void ShowPlayerCards()
        {
            if (HasPlayerCards())
            {
                Console.WriteLine("You need to have some bingo cards first.");
                Console.ReadKey();
            }
            else
            {
                int n = savedCards.Count / 25;
                newSavedCards = SplitList(savedCards, 25);

                Console.WriteLine($"{newSavedCards.Count}");
                for (int d = 0; d < n; d++)
                {
                    Console.WriteLine("\t=======================================================");
                    Console.WriteLine($"\t\t player {PlayerName}, Card:{d + 1} ");
                    Console.WriteLine("\t=======================================================");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("\tB\tI\tN\tG\tO");
                    Console.ResetColor();

                    newSavedCards[d].ToArray();
                    for (int i = 0; i < 5; i++)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            Console.Write($"\t{newSavedCards[d][(j * 5) + i]}");
                        }
                        Console.WriteLine("\n");
                    }

                    Console.WriteLine("\t=======================================================");
                }
            }
            Console.ReadKey();

        }


    }


}