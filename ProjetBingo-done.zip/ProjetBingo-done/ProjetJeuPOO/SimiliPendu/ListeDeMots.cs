﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliPendu
{
    public class ListeDeMots
    {
        private List<string> mots = new List<string>();
       
        public List<string> Mots { get => mots; set => mots = value; }

        public ListeDeMots()
        {
            Mots.Add("good");
            Mots.Add("inaptitude");
            Mots.Add("prudence");
            Mots.Add("vulnerable");
            Mots.Add("croisement");
            Mots.Add("franchir");
            Mots.Add("viable");
            Mots.Add("chevreuil");
            Mots.Add("propagation");
            Mots.Add("envahissante");
            Mots.Add("surpopulation");
            Mots.Add("rigoureuse");
        }

    }
}
