﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliPendu
{
    interface IPendu
    {
        public void Jouer();
        public void AfficherGagnant();
    }
}
