﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetJeuPOO.SimiliPendu
{
    public class Pendu : IPendu
    {
        private ListeDeMots listeDeMots = new ListeDeMots();
        private List<string> mots = new List<string>();
        private string guess;
        private string tmpGuess;
        private  int score;
        private int tryTimes;
        private string playerName;
        private int round;

        public ListeDeMots ListeDeMots { get => listeDeMots; set => listeDeMots = value; }
        public List<string> Mots { get => mots; set => mots = value; }
        public string Guess { get => guess; set => guess = value; }
        public string TmpGuess { get => tmpGuess; set => tmpGuess = value; }
        public int Score { get => score; set => score = value; }
        public int TryTimes { get => tryTimes; set => tryTimes = value; }
        public string PlayerName { get => playerName; set => playerName = value; }
        public int Round { get => round; set => round = value; }

        public Pendu()
        {
            for (int i = 0; i < ListeDeMots.Mots.Count; i++) 
            {
                Mots.Add(ListeDeMots.Mots[i]);
            }
            Score = 0;
            TryTimes = 0;
            Round = 0;
        }
        public void StartPendu(string name) 
        {
            PlayerName = name;
            Console.WriteLine($"\t Player: {PlayerName}");
            
            Jouer();

            AfficherGagnant();

            Console.ReadKey();

            ProgramStartMenu programStartMenu = new ProgramStartMenu();
            programStartMenu.StartMenu();
        }
        public void Jouer()
        {

            Random random = new Random();
            int index;

            string word = " ";
            string patialWord = " ";
            char[] tmp = null;
            char[] tmp2 = null;
            do
            {
                index = random.Next(Mots.Count);
                Guess = Mots[index];

                char[] caracters = new char[Guess.Length];
                caracters = Guess.ToCharArray();
                
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("======================================================");
                Console.WriteLine($"\n The number of characters is {caracters.Length}");
                
                Console.WriteLine("\t New word: ");
                for (int i = 0; i < caracters.Length; i++)
                {                    
                    Console.Write($" _");                    
                }
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\n======================================================");
                Console.ResetColor();

                Console.WriteLine("\n");

                if (caracters.Length > 10)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Do you need some hint?");
                    Console.WriteLine($"You will be taken one point away from you score, \n" +
                        $"will be ok for you? (y)continue or (n) to stop ]");
                    Console.ResetColor();
                    string ans = Console.ReadLine();

                    if (ans.ToLower().Equals("y"))
                    {
                        Score -= 1;
                        int ix = 0;
                        
                        for (int i = 0; i < caracters.Length; i++)
                        {
                            ix = random.Next(caracters.Length);
                            if (i.Equals(ix))
                            {
                                Console.Write($" {caracters[i]}");
                            }
                            else 
                            {
                                Console.Write($" _");
                            }
                        }

                    }
                }


                //Console.WriteLine($"\nguess word: {guess}");

                do
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\tRound: {Round} ");
                    Console.WriteLine($"\nTry Times: {TryTimes}, Current Score: {Score}");
                    Console.WriteLine($"\t{PlayerName}, Enter {caracters.Length} letters");
                    Console.ResetColor();

                    word = Console.ReadLine();
                    tmp = new char[word.Length];

                    while (!(word.Length.Equals(caracters.Length)))
                    {
                        Console.WriteLine("Too long or too short, reenter again.");
                        word = Console.ReadLine();
                    }


                    tmp = word.ToCharArray();

                    tmp2 = new char[tmp.Length];
                    for (int i = 0; i < caracters.Length; i++)
                    {
                        
                        if (tmp[i].Equals(caracters[i]))
                        {
                            tmp2[i] = caracters[i];
                        }
                        else
                        {
                            tmp2[i] = '_';
                        }
                    }

                    for (int i = 0; i < tmp2.Length; i++)
                    {
                        Console.Write($" {tmp2[i]}");
                    }

                    TmpGuess = new string(tmp2);
                    //Console.WriteLine($" tmp: {TmpGuess}");

                    if (!(TryTimes.Equals(5) && Score.Equals(3)))
                    {
                        if (TmpGuess.Equals(guess))
                        {
                            Score++;
                            TryTimes = 0;
                            Round++;
                            Console.WriteLine($"\n\ncongratulations!");
                            Console.ReadKey();
                            break;
                        }
                        else
                        {
                            Console.WriteLine($"\n\nNice try! Keep trying...");
                        }

                        TryTimes++;
                    }
                    

                } while (TryTimes<5);

            } while (Score < 3);
            
        }

        public void AfficherGagnant()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"The word is {Guess}");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine($"You guessed word is {TmpGuess}");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Your score {Score}!");
            Console.ResetColor();
            
        }

    }
}
